import hello;

def test_hello():
    assert hello.hello_world() == "Hello World!"
